package com.http.sheknows

import scala.concurrent.duration._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

class FunctionalSimulation extends Simulation {

  val httpProtocol = http.baseURL("http://sk-cms-sk-varnishl-1kvaeq1u1vgoo-27944494.us-west-2.elb.amazonaws.com/")
    .header("Host","www.sheknows.com")
    //.disableCaching
    //.inferHtmlResources()
    //.proxy(Proxy("127.0.0.1", 52338).httpsPort(52338))

  val templateTest = scenario("templates").exec(
      Templates.get
    )

  setUp(templateTest.inject(
    rampUsersPerSec(1) to 280 during (10 minutes)
    ,constantUsersPerSec(280) during (10 minutes)
    ,rampUsersPerSec(280) to 290 during (1 minutes)
    ,constantUsersPerSec(290) during (10 minutes)
    ,rampUsersPerSec(290) to 320 during (2 minutes)
    ,constantUsersPerSec(320) during (10 minutes)
    )
    .throttle(
      jumpToRps(320)
      /*
      reachRps(280) in (10 minutes)
      holdFor(10 minutes),
      reachRps(290) in (1 minutes),
      holdFor(10 minutes),
      reachRps(320) in (2 minutes),
      holdFor(10 minutes)
      */
    )
  ).protocols(httpProtocol)


  /*
        rampUsersPerSec(1) to 83 during(5 minutes)
        ,rampUsersPerSec(83) to 125 during(15 minutes)
        ,constantUsersPerSec(125) during (25 minutes)

    //  900 seconds
        ,rampUsersPerSec(125) to 150 during(1 minute)
        ,constantUsersPerSec(150) during (5 minutes)
    //  1260 seconds
        ,rampUsersPerSec(150) to 175 during (1 minute)
        ,constantUsersPerSec(175) during (5 minutes)
    //  1620 seconds
        ,rampUsersPerSec(175) to 200 during (1 minute)
        ,constantUsersPerSec(200) during (5 minutes)
    //  1980 seconds
        ,rampUsersPerSec(200) to 225 during (1 minute)
        ,constantUsersPerSec(225) during (5 minutes)
    //  2700 seconds
        ,rampUsersPerSec(225) to 250 during (1 minute)
        ,constantUsersPerSec(250) during (5 minutes)
    //  3060 seconds
*/
}