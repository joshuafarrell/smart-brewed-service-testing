package com.http.connect.sheknows

import io.gatling.core.Predef._
import io.gatling.http.Predef._

object Login {
  val feeder = csv("templates.csv").circular

  val get = feed(feeder)
    .exec(http("${url}/login")
      .get("${url}/login")
      .check(
        status.is(200),
        css("body > div > div > div > form > input[type=\"hidden\"]").saveAs("token")
      )
    )
    .exec(http("${url}/login_check")
      .post("${url}/login_check")
      .queryParam("_csrf_token", "${token}")
      .queryParam("password", "Qwerty@1")
      .queryParam("username","jim.bob@mailinator.com")
      .check(
        status.is(200)
      )
    )
    .exec(http("${url}/logout")
        .get("${url}/logout")
        .check(
          status.is(200)
        )
    )
}
