package com.http.connect.sheknows

import io.gatling.core.Predef._
import io.gatling.http.Predef._

object Register {
  val feeder = csv("templates.csv").circular

  val get = feed(feeder)
    .exec(http("${template} - ${url}")
      .get("${url}")
      .check(
        status.is(200),
        css("#sf-resetcontent > h1")
          .notExists
      )

    )
}
