package com.http.connect

import io.gatling.core.Predef._
import io.gatling.http.Predef._

class FunctionalSimulation extends Simulation {

  val httpProtocol = http.baseURL(System.getProperty("env"))
  /*
  80% read
  10% update
  10% search
   */
  /*
  val templateTest = scenario("templates").exec(
    Templates.get
  )
  System.out.println(System.getProperty("users"));
  //.proxy(Proxy("127.0.0.1", 59753).httpsPort(59753))
  var userTotal: Int = System.getProperty("users").toInt

  setUp(
    templateTest.inject(atOnceUsers(userTotal))
  ).protocols(httpProtocol)
  */
}