package com.service.taxonomychannelsapi

import io.gatling.core.Predef._
import io.gatling.http.Predef._

class LoadSimulation extends Simulation {
    val httpProtocol = http.baseURL("http://localhost:8080/channel")
      .proxy(Proxy("127.0.0.1", 58806).httpsPort(58806))

    val create = scenario("Create")
         .exec(Channel.Create.create)


    var userTotal: Int = 1

    setUp(
      create.inject(
        atOnceUsers(userTotal)
        //rampUsersPerSec(1) to (updateUsers) during (30 seconds)
        //constantUsersPerSec(updateUsers) during (30 seconds)
      )
    ).protocols(httpProtocol)
}