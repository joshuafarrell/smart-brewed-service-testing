package com.service.genericcontentapi

import io.gatling.core.Predef._
import io.gatling.http.Predef._

class LoadSimulation extends Simulation {

  val httpProtocol = http.baseURL("http://localhost:8080/contents")
    .proxy(Proxy("127.0.0.1", 58806).httpsPort(58806))

  /*
  80% read
  10% update
  10% search
   */
  val create = scenario("create").exec(
    //contenttype.Create.create
    contents.Create.create
  )
  var userTotal: Int = 1

  setUp(
    create.inject(atOnceUsers(userTotal))
  ).protocols(httpProtocol)
}