package com.service.genericcontentapi.contents

import io.gatling.core.Predef._
import io.gatling.http.Predef._

object Create {
  val headers = Map(
    "content-type" -> "application/json; charset=utf-8"
  )

  val create = exec(http("POST /")
    .post("/")
    .headers(headers)
    .body(StringBody(
       """{
             "createdBy": 48,
             "authorId": 63,
             "type": "test",
             "title": "Title",
             "publishAfter": 1457541343247,
             "disabled": true
          }""")).asJSON

  )
}
