package com.service.workflowapi.workflow

import io.gatling.core.Predef._
import io.gatling.http.Predef._

object Create {
  val headers = Map(
    "content-type" -> "application/json; charset=utf-8"
  )

  val create = exec(http("POST_create")
    .post("/")
    .headers(headers)
    .body(StringBody(
      """{
          "name": "Article Workflow",
          "alias": "article-workflow",
          "description": "This is the article publication workflow",
          "steps": [
            {
              "name": "Draft Created",
              "alias": "draft-created",
              "description": "An article draft has been created",
              "nextSteps": [
                "verified"
              ]
            },
            {
              "name": "Verified by Editor",
              "alias": "verified",
              "description": "Article is verified by Editor",
              "nextSteps": [
                "published"
              ]
            },
            {
              "name": "Published",
              "alias": "published",
              "description": "Article is published",
              "nextSteps": [
                "unpublished"
              ]
            },
            {
              "name": "Unpublished",
              "alias": "unpublished",
              "description": "Article is unpublished",
              "nextSteps": [
                "published",
                "deleted"
              ]
            },
            {
              "name": "Deleted",
              "alias": "deleted",
              "description": "Article is deleted"
            }
          ],
          "firstStep": "draft-created"
        }""")).asJSON
    .check(
      status.is(200),
      jsonPath("$.id").ofType[Int].saveAs("userId")
    )
  )
}
