package com.service.workflowapi.modelstate

import io.gatling.core.Predef._
import io.gatling.http.Predef._

object Create {
  val headers = Map(
    "content-type" -> "application/json; charset=utf-8"
  )

  val create = exec(http("POST_create")
    .post("/models/states")
    .headers(headers)
    .body(StringBody(
      """{
          "stepId": 1,
          "modelId": 98765,
          "modelNamespace": "sheknows/article",
          "createdBy": 3234
        }""")).asJSON
    .check(status.is(200))

  )
}
