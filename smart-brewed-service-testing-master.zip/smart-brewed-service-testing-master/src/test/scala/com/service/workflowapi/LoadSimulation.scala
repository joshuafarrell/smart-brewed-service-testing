package com.service.workflowapi

import io.gatling.core.Predef._
import io.gatling.http.Predef._

class LoadSimulation extends Simulation {

  val httpProtocol = http.baseURL("http://localhost:8080/workflows-api/workflows")
  .proxy(Proxy("127.0.0.1", 54908).httpsPort(54908))

  val create = scenario("create").exec(
    step.Create.create
  )

  var userTotal: Int = 1

  setUp(
    create.inject(atOnceUsers(userTotal))
  ).protocols(httpProtocol)

}