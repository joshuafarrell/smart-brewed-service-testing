package com.service.workflowapi.step

import io.gatling.core.Predef._
import io.gatling.http.Predef._

object Create {
  val headers = Map(
    "content-type" -> "application/json; charset=utf-8"
  )

  val create = exec(http("POST_create")
    .post("/1/steps")
    .headers(headers)
    .body(StringBody(
      """{
          "name": "SEO Approved",
          "alias": "seo-approved2",
          "description": "Article SEO Approved",
          "nextSteps": [
            "published"
          ]
        }""")).asJSON
    .check(status.is(200))

  )
}
