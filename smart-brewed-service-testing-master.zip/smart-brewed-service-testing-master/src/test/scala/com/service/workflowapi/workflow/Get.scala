package com.service.workflowapi.workflow

import io.gatling.core.Predef._
import io.gatling.http.Predef._

object Get {
  val headers = Map(
    "content-type" -> "application/json; charset=utf-8"
  )

  val byId = exec(http("GET_byId")
    .get("/1")
    .headers(headers)
    .check(status.is(200))
  )
}