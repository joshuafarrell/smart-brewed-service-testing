package utils

import scala.beans.BeanProperty

class UserAgent {
  @BeanProperty var ie11: String = null
  @BeanProperty var ie10: String = null
  @BeanProperty var ie9: String = null
  @BeanProperty var chrome: String = null
  @BeanProperty var firefox: String = null
  @BeanProperty var opera: String = null
  @BeanProperty var iphone: String = null
  @BeanProperty var windows: String = null
  @BeanProperty var android: String = null

  def getUserAgent(agent: String)=
    agent match {
      case "ie11" => ie11
      case "ie10" => ie10
      case "ie9" => ie9
      case "chrome" => chrome
      case "firefox" => firefox
      case "opera" => opera
      case "iphone" => iphone
      case "windows" => windows
      case "android" => android
    }
}
