#!/usr/bin/env bash

GATLING_VERSION=2.2.0-SNAPSHOT

mkdir -p gatling
cd gatling
curl https://oss.sonatype.org/content/repositories/snapshots/io/gatling/highcharts/gatling-charts-highcharts-bundle/${GATLING_VERSION}/gatling-charts-highcharts-bundle-2.2.0-20160311.104423-397-bundle.zip -o gatling-charts-highcharts-bundle-${GATLING_VERSION}-bundle.zip
unzip gatling-charts-highcharts-bundle-${GATLING_VERSION}-bundle.zip