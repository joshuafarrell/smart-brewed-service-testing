#!/usr/bin/env bash

mvn clean package -Dgatling.simulation=com.http.sheknows.FunctionalSimulation -Dusers=1 -Denv=http://www.sheknows.com